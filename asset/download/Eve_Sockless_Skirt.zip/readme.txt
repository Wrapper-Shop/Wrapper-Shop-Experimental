﻿EVE SOCKLESS SKIRT

Created by Chinese Scout (PeedyParrotYes HelloJadooNo)

HOW TO INSTALL FOR GOANIFIRE/GOANIMATE WRAPPER/GA4SR/WRAPPER ONLINE USERS:

1. On Github, Go to your GoAnimate assets repository.

2. Create a new folder by using a name "eve_b010", then type the symbol "/".

3. Upload files that are included on this folder.

4. Go to the Family Folder, Then go to the cc_theme.xml file.

5. Scroll down until you find one of the following:

<component type="lower_body" id="eve_b010" path="eve_b010" name="eve_b010" thumb="thumbnail.swf" money="0" sharing="0" enable="Y">
	<state id="dance" filename="dance.swf"/>
	<state id="default" filename="default.swf"/>
	<state id="excited" filename="excited.swf"/>
	<state id="fearful" filename="fearful.swf"/>
	<state id="kneel_down" filename="kneel_down.swf"/>
	<state id="laugh" filename="laugh.swf"/>
	<state id="lie_down" filename="lie_down.swf"/>
	<state id="run" filename="run.swf"/>
	<state id="sit" filename="sit.swf"/>
	<state id="walk" filename="walk.swf"/>
</component>

6. Copy the whole component, create a new line, and replace the "xx" with the number you set the Leather Jacket folder to.

7. You're done! Go to the Character Creator on GoAniFire/GoAnimate Wrapper/GoAnimate for Schools Remastered/Wrapper Online and the Jacket should be there!

HOW TO INSTALL FOR WRAPPER OFFLINE USERS:

1. Extract the "eve_b010" folder located in "eve_lower_body" into "(VERSION)\wrapper\server\store\3a981f5cb2739137\cc_store\family\upper_body".

2. Edit "cc_theme.xml" and add the following below.

<component type="lower_body" id="eve_b010" path="eve_b010" name="eve_b010" thumb="thumbnail.swf" money="0" sharing="0" enable="Y">
	<state id="dance" filename="dance.swf"/>
	<state id="default" filename="default.swf"/>
	<state id="excited" filename="excited.swf"/>
	<state id="fearful" filename="fearful.swf"/>
	<state id="kneel_down" filename="kneel_down.swf"/>
	<state id="laugh" filename="laugh.swf"/>
	<state id="lie_down" filename="lie_down.swf"/>
	<state id="run" filename="run.swf"/>
	<state id="sit" filename="sit.swf"/>
	<state id="walk" filename="walk.swf"/>
</component>

3. When you've done, just save it.

4. Go to Comedy World Character Creator on W: Off and the skirt should be here by da wae!

If you have any ossues, or I don't want that, please contact me on Discord: PeedyParrotYesHelloJadooNo#9958